import pandas as pd
from haversine import haversine, Unit
from tqdm import tqdm

# Leer tu dataset original
df = pd.read_excel("dataset_reserva.xlsx")

# Crear dataframe de resultado
rutas = []

# Iterar por todos los pares posibles
for i, row_i in tqdm(df.iterrows(), total=len(df)):
    for j, row_j in df.iterrows():
        if i != j:
            origen = row_i['restaurante_inicio']
            destino = row_j['restaurante_final']
            lat_i, lon_i = row_i['lat_inicio'], row_i['lon_inicio']
            lat_j, lon_j = row_j['lat_final'], row_j['lon_final']

            distancia = haversine((lat_i, lon_i), (lat_j, lon_j), unit=Unit.KILOMETERS)
            tiempo = distancia / 30 * 60  # 30 km/h -> minutos

            rutas.append({
                "restaurante_inicio": origen,
                "restaurante_final": destino,
                "lat_inicio": lat_i,
                "lon_inicio": lon_i,
                "lat_final": lat_j,
                "lon_final": lon_j,
                "distancia_km": round(distancia, 3),
                "restaurante_tiempo": round(tiempo, 2)
            })

# Guardar en un nuevo Excel
df_rutas = pd.DataFrame(rutas)
df_rutas.to_csv("rutas_completas_simuladas.csv", index=False)
print("Archivo generado: rutas_completas_simuladas.xlsx")
