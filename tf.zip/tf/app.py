from flask import Flask, render_template, request
import pandas as pd
import networkx as nx
import folium
import osmnx as ox
import os
import pickle

app = Flask(__name__)
data_file = "rutas_completas_simuladas.csv"
map_file = "static/mapa.html"

G_osm = None
restaurantes_nodos = {}

def inicializar_grafo_osm():
    global G_osm, restaurantes_nodos

    graph_file = "lima_calles.graphml"
    nodos_file = "nodos_osm.pkl"

    if os.path.exists(graph_file):
        G_osm = ox.load_graphml(graph_file)
    else:
        G_osm = ox.graph_from_place("Lima, Peru", network_type="drive")
        ox.save_graphml(G_osm, graph_file)

    if os.path.exists(nodos_file):
        with open(nodos_file, "rb") as f:
            restaurantes_nodos = pickle.load(f)
        return

    df = pd.read_csv(data_file)
    nodos = {}

    for _, row in df.iterrows():
        for name, lat, lon in [(row['restaurante_inicio'], row['lat_inicio'], row['lon_inicio']),
                               (row['restaurante_final'], row['lat_final'], row['lon_final'])]:
            if name not in nodos:
                try:
                    nearest = ox.distance.nearest_nodes(G_osm, lon, lat)
                    nodos[name] = {
                        "lat": lat,
                        "lon": lon,
                        "osm_node": nearest
                    }
                except Exception as e:
                    print(f"Error localizando nodo para {name}: {e}")
                    continue

    with open(nodos_file, "wb") as f:
        pickle.dump(nodos, f)

    restaurantes_nodos = nodos

def calcular_ruta_dijkstra(origen, destino):
    nodo_origen = restaurantes_nodos[origen]["osm_node"]
    nodo_destino = restaurantes_nodos[destino]["osm_node"]
    return nx.shortest_path(G_osm, nodo_origen, nodo_destino, weight="length")

def calcular_ruta_tsp_heuristica(origen, destinos):
    visitados = [origen]
    no_visitados = destinos.copy()
    ruta_final = []
    nodo_actual = origen
    total_distancia = 0

    while no_visitados:
        mejor_ruta = None
        menor_costo = float("inf")
        siguiente = None

        for candidato in no_visitados:
            try:
                ruta = calcular_ruta_dijkstra(nodo_actual, candidato)
                costo = calcular_longitud_ruta(ruta)[0]
                if costo < menor_costo:
                    menor_costo = costo
                    mejor_ruta = ruta
                    siguiente = candidato
            except:
                continue

        if not mejor_ruta:
            return [], 0

        ruta_final += mejor_ruta if not ruta_final else mejor_ruta[1:]
        total_distancia += menor_costo
        visitados.append(siguiente)
        no_visitados.remove(siguiente)
        nodo_actual = siguiente

    return ruta_final, total_distancia

def calcular_longitud_ruta(ruta):
    distancia_m = sum(G_osm[u][v][0]['length'] for u, v in zip(ruta[:-1], ruta[1:]))
    distancia_km = distancia_m / 1000
    tiempo_min = (distancia_km / 25) * 60
    return distancia_m, tiempo_min

def graficar_ruta_folium(ruta_nodos, origen_nombre, destino_nombre=None, modo_tsp=False):
    m = folium.Map(location=(G_osm.nodes[ruta_nodos[0]]['y'], G_osm.nodes[ruta_nodos[0]]['x']), zoom_start=13)
    
    # Añadir líneas con popup solo entre restaurantes
    nodos_restaurantes = {data['osm_node']: name for name, data in restaurantes_nodos.items()}
    puntos_restaurante = [n for n in ruta_nodos if n in nodos_restaurantes]

    for i in range(len(puntos_restaurante) - 1):
        n1, n2 = puntos_restaurante[i], puntos_restaurante[i + 1]
        ruta_parcial = nx.shortest_path(G_osm, n1, n2, weight="length")
        coords = [(G_osm.nodes[n]['y'], G_osm.nodes[n]['x']) for n in ruta_parcial]
        distancia, tiempo = calcular_longitud_ruta(ruta_parcial)

        folium.PolyLine(
            locations=coords,
            color="blue",
            weight=5,
            popup=folium.Popup(f"{nodos_restaurantes[n1]} → {nodos_restaurantes[n2]}<br>{distancia:.0f} m | {tiempo:.1f} min", max_width=300)
        ).add_to(m)

    # Marcadores
    for i, n in enumerate(puntos_restaurante):
        nombre = nodos_restaurantes[n]
        lat, lon = G_osm.nodes[n]['y'], G_osm.nodes[n]['x']
        color = "green" if i == 0 else ("red" if i == len(puntos_restaurante) - 1 else "blue")
        folium.Marker(
            location=(lat, lon),
            icon=folium.Icon(color=color),
            popup=f"{i+1}. {nombre}"
        ).add_to(m)

    m.save(map_file)

@app.route("/", methods=["GET", "POST"])
def index():
    if G_osm is None or not restaurantes_nodos:
        inicializar_grafo_osm()

    nodos = sorted(restaurantes_nodos.keys())
    resultado = None
    mapa = None

    if request.method == "POST":
        accion = request.form.get("accion")
        if accion == "mostrar_todas":
            primer = next(iter(restaurantes_nodos.values()))
            m = folium.Map(location=[primer["lat"], primer["lon"]], zoom_start=13)
            for nombre, data in restaurantes_nodos.items():
                folium.Marker([data["lat"], data["lon"]], tooltip=nombre, icon=folium.Icon(color='blue')).add_to(m)
            m.save(map_file)
            mapa = map_file

        elif accion == "calcular_ruta":
            origen = request.form.get("origen")
            destinos = request.form.getlist("destinos")
            algoritmo = request.form.get("algoritmo")
            destinos = [d for d in destinos if d != origen]

            try:
                if algoritmo == "Dijkstra":
                    if len(destinos) != 1:
                        raise Exception("Dijkstra requiere un solo destino.")
                    destino = destinos[0]
                    ruta = calcular_ruta_dijkstra(origen, destino)
                    distancia, tiempo = calcular_longitud_ruta(ruta)
                    graficar_ruta_folium(ruta, origen, destino)
                    resultado = {
                        "ruta": f"{origen} → {destino}",
                        "costo": f"{distancia / 1000:.2f} km",
                        "tiempo": f"{tiempo:.1f} minutos",
                        "algoritmo": "Dijkstra"
                    }
                    mapa = map_file

                elif algoritmo == "TSP":
                    if not destinos:
                        raise Exception("Debes seleccionar al menos un destino.")
                    ruta, distancia = calcular_ruta_tsp_heuristica(origen, destinos)
                    if not ruta:
                        raise Exception("No se pudo calcular una ruta TSP válida.")
                    graficar_ruta_folium(ruta, origen, modo_tsp=True)
                    tiempo = (distancia / 1000 / 25) * 60
                    resultado = {
                        "ruta": f"{origen} → {' → '.join(destinos)}",
                        "costo": f"{distancia / 1000:.2f} km",
                        "tiempo": f"{tiempo:.1f} minutos",
                        "algoritmo": "TSP heurístico"
                    }
                    mapa = map_file

            except Exception as e:
                resultado = {"error": str(e)}

    return render_template("index.html", nodos=nodos, resultado=resultado, mapa=map_file)

if __name__ == "__main__":
    app.run(debug=True)
