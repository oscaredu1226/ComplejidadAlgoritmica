from flask import Flask, render_template, request
import pandas as pd
import networkx as nx
import folium
import heapq
import os

app = Flask(__name__)

data_file = "rutas_completas_simuladas.csv"
map_file = "static/mapa.html"

def construir_grafo():
    df = pd.read_csv(data_file)
    df.columns = df.columns.str.strip()

    G = nx.DiGraph()
    nodos_pos = {}

    for _, row in df.iterrows():
        origen = row['restaurante_inicio']
        destino = row['restaurante_final']
        tiempo = row['restaurante_tiempo']
        distancia = row['distancia_km']

        if origen not in nodos_pos:
            nodos_pos[origen] = (row['lat_inicio'], row['lon_inicio'])
        if destino not in nodos_pos:
            nodos_pos[destino] = (row['lat_final'], row['lon_final'])

        G.add_edge(origen, destino, tiempo=tiempo, distancia=distancia)

    for nodo, coords in nodos_pos.items():
        G.nodes[nodo]['pos'] = coords

    return G

def graficar_mapa_todas_pollerias(G):
    coordenadas = [data['pos'] for _, data in G.nodes(data=True)]
    m = folium.Map(location=coordenadas[0], zoom_start=12)

    for lat, lon in coordenadas:
        folium.Marker(location=(lat, lon), icon=folium.Icon(color='blue')).add_to(m)

    m.save(map_file)

def dijkstra_manual(graph, start, end):
    distances = {node: float('inf') for node in graph.nodes}
    previous = {node: None for node in graph.nodes}
    distances[start] = 0
    queue = [(0, start)]
    while queue:
        current_distance, current = heapq.heappop(queue)
        if current == end:
            break
        for neighbor in graph.successors(current):
            weight = graph[current][neighbor]['tiempo']
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous[neighbor] = current
                heapq.heappush(queue, (distance, neighbor))
    path = []
    current = end
    while current:
        path.insert(0, current)
        current = previous[current]
    return path, distances[end]

def ruta_mas_eficiente_dijkstra(G, origen, destinos):
    ruta = [origen]
    total = 0
    pendientes = set(destinos)
    actual = origen

    while pendientes:
        mejor = None
        mejor_ruta = []
        menor_costo = float("inf")
        for destino in pendientes:
            try:
                camino, costo = dijkstra_manual(G, actual, destino)
                if costo < menor_costo:
                    mejor = destino
                    menor_costo = costo
                    mejor_ruta = camino
            except:
                continue
        if not mejor:
            break
        ruta += mejor_ruta[1:]
        total += menor_costo
        pendientes.remove(mejor)
        actual = mejor

    return ruta, total

def graficar_ruta_folium(graph, ruta):
    coords = [graph.nodes[nodo]['pos'] for nodo in ruta]
    m = folium.Map(location=coords[0], zoom_start=13)

    # Marcadores con colores según posición
    for i, nodo in enumerate(ruta):
        lat, lon = graph.nodes[nodo]['pos']
        if i == 0:
            color = 'green'
        elif i == len(ruta) - 1:
            color = 'red'
        else:
            color = 'blue'

        # Marcador con tooltip
        folium.Marker(
            location=(lat, lon),
            tooltip=nodo,
            icon=folium.Icon(color=color)
        ).add_to(m)

        # Card con nombre
        folium.Marker(
            location=(lat, lon),
            icon=folium.DivIcon(
                icon_size=(150, 36),
                icon_anchor=(0, 0),
                html=f"""
                    <div style="
                        background-color: white;
                        border: 2px solid {color};
                        border-radius: 6px;
                        padding: 4px 8px;
                        font-size: 12px;
                        font-weight: bold;
                        color: {color};
                        white-space: nowrap;
                        box-shadow: 0 0 5px rgba(0,0,0,0.3);
                        ">
                        {nodo}
                    </div>
                """
            )
        ).add_to(m)

    # Aristas con etiquetas de peso
    for i in range(len(ruta) - 1):
        u, v = ruta[i], ruta[i + 1]
        data = graph[u][v]
        lat1, lon1 = graph.nodes[u]['pos']
        lat2, lon2 = graph.nodes[v]['pos']
        label = f"{data['distancia']} km / {data['tiempo']:.1f} min"

        folium.PolyLine(
            locations=[(lat1, lon1), (lat2, lon2)],
            color="red",
            weight=5,
            opacity=0.8
        ).add_to(m)

        mid_lat = (lat1 + lat2) / 2
        mid_lon = (lon1 + lon2) / 2

        folium.map.Marker(
            [mid_lat, mid_lon],
            icon=folium.DivIcon(
                html=f"""
                <div style="
                    background-color: white;
                    border: 2px solid #1976D2;
                    border-radius: 8px;
                    padding: 4px 8px;
                    font-size: 13px;
                    font-weight: 500;
                    color: #1976D2;
                    white-space: nowrap;
                    box-shadow: 0 0 6px rgba(0,0,0,0.25);
                    display: inline-block;
                    min-width: 110px;
                    text-align: center;
                ">
                    {label}
                </div>
                """
            )
        ).add_to(m)

    m.save(map_file)



@app.route('/', methods=['GET', 'POST'])
def index():
    G = construir_grafo()
    nodos = sorted(G.nodes)
    resultado = None
    mapa = None

    if request.method == 'POST':
        accion = request.form.get("accion")
        if accion == "mostrar_todas":
            graficar_mapa_todas_pollerias(G)
            mapa = map_file
        elif accion == "calcular_ruta":
            origen = request.form.get("origen")
            destinos = request.form.getlist("destinos")
            try:
                if not origen or not destinos:
                    raise Exception("Debes seleccionar un origen y al menos un destino.")
                ruta, costo = ruta_mas_eficiente_dijkstra(G, origen, destinos)
                graficar_ruta_folium(G, ruta)
                resultado = {
                    'ruta': " → ".join(ruta),
                    'costo': f"{costo:.2f} minutos",
                    'algoritmo': "Dijkstra (heurístico)"
                }
                mapa = map_file
            except Exception as e:
                resultado = {'error': str(e)}
    else:
        graficar_mapa_todas_pollerias(G)
        mapa = map_file

    return render_template("index.html", nodos=nodos, resultado=resultado, mapa=mapa)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
